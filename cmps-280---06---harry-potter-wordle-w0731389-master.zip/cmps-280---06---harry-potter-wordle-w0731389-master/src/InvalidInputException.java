class InvalidInputException {

}